local fileroot = ".\\content\\TournamentCornerFlags"

local tid

local function set_random(ctx)
	tid = ctx.tournament_id
	home = ctx.home_team
	away = ctx.away_team
        cuproundid = ctx.match_info
end

function make_key(ctx, filename)
    -- Master League/BAL/League/Cup
    if (home == 109) and (tid == 2 or tid == 1026 or tid == 4 or tid == 2050 or tid == 3074 or tid == 4098 or tid == 5122 or tid == 6146 or tid == 7170 or tid == 8149 or tid == 3  or tid == 1027 or tid == 2051 or tid == 3075 or tid == 4099 or tid == 5123 or tid == 6147 or tid == 7171 or tid == 8195) then
	      CornerFlag = "Teams\\Real Madrid\\CL"
        elseif tid == 2 or tid == 1026 or tid == 4 or tid == 2050 or tid == 3074 or tid == 4098 or tid == 5122 or tid == 6146 or tid == 7170 or tid == 8149 or tid == 3  or tid == 1027 or tid == 2051 or tid == 3075 or tid == 4099 or tid == 5123 or tid == 6147 or tid == 7171 or tid == 8195 then
	      CornerFlag = "UEFA Champions League"
        elseif tid == 17 then
		 CornerFlag = "Premier League"
	elseif tid == 118 then
		 CornerFlag = "Ligue 1"
	elseif tid == 61 then
		 CornerFlag = "Ligue 2"
	elseif tid == 5 or tid == 1029 or tid == 2053 or tid == 3077 or tid == 4104 or tid == 5125 or tid == 6149 or tid == 7173 or tid == 8197 or tid == 9221 or tid == 10245  or tid == 11269 or tid == 12293 or tid == 6 then
	     CornerFlag = "UEFA Europa League"
	elseif tid == 79 then
		 CornerFlag = "EFL\\Championship"
	elseif tid == 83 then
		 CornerFlag = "EFL\\Play-Off"
	elseif tid == 86 then
		 CornerFlag = "Community Shield"
        elseif (home == 109) and (tid == 19) then
		 CornerFlag = "Teams\\Real Madrid\\Liga"
        elseif (home == 29) and (tid == 65535) then
		 CornerFlag = "Teams\\National"
        elseif (home == 1168) and (tid == 65535) then
		 CornerFlag = "Teams\\National"
        elseif (home == 54) and (tid == 65535) then
		 CornerFlag = "Teams\\National"
        elseif (home == 56) and (tid == 65535) then
		 CornerFlag = "Teams\\National"
        elseif (home == 8) and (tid == 65535) then
		 CornerFlag = "Teams\\National"
        elseif (home == 31) and (tid == 65535) then
		 CornerFlag = "Teams\\National"
        elseif tid == 80 then
		 CornerFlag = "LaLiga"
	elseif tid == 19 then
		 CornerFlag = "LaLiga"
	elseif tid == 23 then
	     CornerFlag = "FA Cup"
        elseif (home == 119) and (tid == 18) then
	     CornerFlag = "Teams\\Inter"
	elseif tid == 18 then
	     CornerFlag = "Serie A"
	elseif tid == 125 then
		 CornerFlag = "Coupe de France"
	elseif tid == 21 then
		 CornerFlag = "Eredivisie"
	elseif tid == 20 then
		 CornerFlag = "Super Lig"
	elseif tid == 115 or tid == 155 or tid == 156 or tid == 157 or tid == 158 or tid == 159 then
		 CornerFlag = "Jupiler Pro League"
	elseif tid == 133 or tid == 134 or tid == 135 or tid == 136 or tid == 137 then
		 CornerFlag = "SPFL"
	elseif tid == 50 then
	     CornerFlag = "Bundesliga"
	elseif tid == 30 then
		 CornerFlag = "Superliga Argentina"
	elseif tid == 53 then
	     CornerFlag = "DFB Pokal"
	elseif tid == 95 then
	     CornerFlag = "DFL Supercup"
	elseif tid == 59 then
		 CornerFlag = "Copa Argentina"	 
	elseif tid == 8 or tid == 9 or tid == 6153 or tid == 1032 or tid == 2056 or tid == 3080 or tid == 4104 or tid == 3081 or tid == 4105 or tid == 5129 or tid == 7177 or tid == 8201 or tid == 10 then
		 CornerFlag = "Copa Libertadores"
    elseif tid == 34 or tid == 1058 or tid == 2082 or tid == 3106 or tid == 4130 or tid == 5154 or tid == 6178 or tid == 7202 or tid == 8226 or tid == 35 then
	      CornerFlag = "FIFA World Cup"
	elseif tid == 7 then
		 CornerFlag = "UEFA Super Cup"
        elseif (tid == 42) and (cuproundid == 53) then
	     CornerFlag = "UEFA Euros\\UEFA Euro Final"
        elseif (home == 015) and (ctx.stadium == 009) and (tid == 41 or tid == 1065 or tid == 2089 or tid == 3113 or tid == 4137 or tid == 5161 or tid == 6185 or tid == 8200 or tid == 8201 or tid == 8202 or tid == 8203 or tid == 8204 or tid == 8205) then
	     CornerFlag = "UEFA Euros\\UEFA Euro Copenhagen"
        elseif (home == 026) and (ctx.stadium == 009) and (tid == 41 or tid == 1065 or tid == 2089 or tid == 3113 or tid == 4137 or tid == 5161 or tid == 6185 or tid == 8200 or tid == 8201 or tid == 8202 or tid == 8203 or tid == 8204 or tid == 8205) then
	     CornerFlag = "UEFA Euros\\UEFA Euro Bucharest"
        elseif (home == 001) and (ctx.stadium == 009) and (tid == 41 or tid == 1065 or tid == 2089 or tid == 3113 or tid == 4137 or tid == 5161 or tid == 6185 or tid == 8200 or tid == 8201 or tid == 8202 or tid == 8203 or tid == 8204 or tid == 8205) then
	     CornerFlag = "UEFA Euros\\UEFA Euro Dublin"
        elseif (ctx.stadium == 046) and (tid == 41 or tid == 1065 or tid == 2089 or tid == 3113 or tid == 4137 or tid == 5161 or tid == 6185 or tid == 8200 or tid == 8201 or tid == 8202 or tid == 8203 or tid == 8204 or tid == 8205) then
	     CornerFlag = "UEFA Euros\\UEFA Euro Bilbao"
        elseif (ctx.stadium == 084) and (tid == 41 or tid == 1065 or tid == 2089 or tid == 3113 or tid == 4137 or tid == 5161 or tid == 6185 or tid == 8200 or tid == 8201 or tid == 8202 or tid == 8203 or tid == 8204 or tid == 8205) then
	     CornerFlag = "UEFA Euros\\UEFA Euro St.Petersburg"
        elseif (ctx.stadium == 070) and (tid == 41 or tid == 1065 or tid == 2089 or tid == 3113 or tid == 4137 or tid == 5161 or tid == 6185 or tid == 8200 or tid == 8201 or tid == 8202 or tid == 8203 or tid == 8204 or tid == 8205) then
	     CornerFlag = "UEFA Euros\\UEFA Euro Amsterdam"
        elseif (ctx.stadium == 006) and (tid == 41 or tid == 1065 or tid == 2089 or tid == 3113 or tid == 4137 or tid == 5161 or tid == 6185 or tid == 8200 or tid == 8201 or tid == 8202 or tid == 8203 or tid == 8204 or tid == 8205) then
	     CornerFlag = "UEFA Euros\\UEFA Euro Rome"
        elseif (ctx.stadium == 031) and (tid == 41 or tid == 1065 or tid == 2089 or tid == 3113 or tid == 4137 or tid == 5161 or tid == 6185 or tid == 8200 or tid == 8201 or tid == 8202 or tid == 8203 or tid == 8204 or tid == 8205) then
	     CornerFlag = "UEFA Euros\\UEFA Euro Munich"
        elseif (ctx.stadium == 005 or ctx.stadium == 083) and (tid == 41 or tid == 1065 or tid == 2089 or tid == 3113 or tid == 4137 or tid == 5161 or tid == 6185 or tid == 8200 or tid == 8201 or tid == 8202 or tid == 8203 or tid == 8204 or tid == 8205) then
	     CornerFlag = "UEFA Euros\\UEFA Euro London"
	elseif tid == 41 or tid == 1065 or tid == 2089 or tid == 3113 or tid == 4137 or tid == 5161 or tid == 6185 or tid == 8200 or tid == 8201 or tid == 8202 or tid == 8203 or tid == 8204 or tid == 8205 then
	     CornerFlag = "UEFA Euros\\UEFA Euro"
	elseif tid == 43 or tid == 45 or tid == 104 or tid == 8800 or tid == 8801 or tid == 8802 or tid == 8803 or tid == 20800 or tid == 20801 or tid == 20802 then
		 CornerFlag = "Copa America"
	elseif tid == 44 then
		 CornerFlag = "AFC Asian Cup"
	elseif tid == 46 then
		 CornerFlag = "Africa Cup of Nations"
	elseif tid == 1 then
		 CornerFlag = "FIFA Club World Cup"
	elseif tid == 105 or tid == 106 or tid == 107 then
		 CornerFlag = "International Champions Cup"
	elseif tid == 25 then
		 CornerFlag = "Copa del Rey"
	elseif tid == 87 then
		 CornerFlag = "Supercopa de Espana"
	elseif tid == 130 then
		 CornerFlag = "Trophee des Champions"
	elseif tid == 22 then
		 CornerFlag = "Liga NOS"
	elseif tid == 24 then
		 CornerFlag = "Coppa Italia"
	elseif tid == 89 then
		 CornerFlag = "Supercoppa Italiana"
	elseif tid == 27 then
		 CornerFlag = "KNVB Beker"
	elseif tid == 90 then
		 CornerFlag = "Johan Cruyff Shield"
	elseif tid == 28 then
		 CornerFlag = "Taca de Portugal"
	elseif tid == 91 then
		 CornerFlag = "Supertaca Cândido de Oliveira"
	elseif tid == 117 then
		 CornerFlag = "Raiffeisen Super League"
	elseif tid == 124 then
		 CornerFlag = "Swiss Cup"
	elseif tid == 112 then
		 CornerFlag = "Croky Cup"
	elseif tid == 128 then
		 CornerFlag = "Belgian Super Cup"
	elseif tid == 26 then
		 CornerFlag = "Turkish Cup"
	elseif tid == 88 then
		 CornerFlag = "Turkish Super Cup"
	elseif tid == 141 or tid == 142 or tid == 147 or tid == 148 or tid == 149 or tid == 150 or tid == 151 then
		 CornerFlag = "Danish Superliga"
	elseif tid == 119 or tid == 23800 or tid == 23801 or tid == 160 or tid == 161 then
		 CornerFlag = "Liga Aguila"
	elseif tid == 126 then
		 CornerFlag = "Copa Colombia"
	elseif tid == 131 then
		 CornerFlag = "Superliga Colombiana"
	elseif tid == 67 or tid == 13400 or tid == 13401 then
		 CornerFlag = "Chilean Primera Division"
	elseif tid == 68 then
		 CornerFlag = "Copa Chile"
	elseif tid == 92 then
		 CornerFlag = "Supercopa Argentina"
	elseif tid == 29 then
		 CornerFlag = "Brasileiro"
	elseif tid == 31 then
		 CornerFlag = "Copa do Brasil"
    elseif tid == 65535 or tid == 47 or tid == 99 or tid == 9400 or tid == 9401 or tid == 9402 or tid == 9403 or tid == 9404 or tid == 9405 or tid == 9406 or tid == 9407 or tid == 48 then
	    --Exhibition
	    if (home == 101 or home == 4071 or home == 377 or home == 378 or home == 379 or home == 102 or home == 382 or home == 177 or home == 178 or home == 2610 or home == 204 or home == 103 or home == 173 or home == 100 or home == 106 or home == 207 or home == 179 or home == 398 or home == 105 or home == 208) and (away == 101 or away == 4071 or away == 377 or away == 378 or away == 379 or away == 102 or away == 382 or away == 177 or away == 178 or away == 2610 or away == 204 or away == 103 or away == 173 or away == 100 or away == 106 or away == 207 or away == 179 or away == 398 or away == 105 or away == 208) then
	        CornerFlag = "Premier League"
		elseif (home == 4200 or home == 403 or home == 115 or home == 405 or home == 1328 or home == 211 or home == 213 or home == 112 or home == 215 or home == 216 or home == 217 or home == 1910 or home == 181 or home == 113 or home == 114 or home == 218 or home == 418 or home == 1330 or home == 4213 or home == 221) and (away == 4200 or away == 403 or away == 115 or away == 405 or away == 1328 or away == 211 or away == 213 or away == 112 or away == 215 or away == 216 or away == 217 or away == 1910 or away == 181 or away == 113 or away == 114 or away == 218 or away == 418 or away == 1330 or away == 4213 or away == 221) then
	        CornerFlag = "Ligue 1"
	    elseif (home == 379 or home == 209 or home == 180 or home == 5019 or home == 1329 or home == 406 or home == 407 or home == 2611 or home == 4370 or home == 413 or home == 414 or home == 4123 or home == 415 or home == 416 or home == 4210 or home == 4211 or home == 182 or home == 4212 or home == 219 or home == 420 or home == 1528) and (away == 209 or away == 180 or away == 5019 or away == 1329 or away == 406 or away == 407 or away == 2611 or away == 4370 or away == 413 or away == 414 or away == 4123 or away == 415 or away == 416 or away == 4210 or away == 4211 or away == 182 or away == 4212 or away == 219 or away == 420 or away == 1528) then
	        CornerFlag = "Ligue 2"
	    elseif (home == 107 or home == 201 or home == 176 or home == 202 or home == 4180 or home == 1760 or home == 383 or home == 1589 or home == 386 or home == 104 or home == 205 or home == 387 or home == 388 or home == 389 or home == 4192 or home == 1327 or home == 391 or home == 4193 or home == 4194 or home == 394 or home == 395 or home == 1909 or home == 399 or home == 400) and (away == 107 or away == 201 or away == 176 or away == 202 or away == 4180 or away == 1760 or away == 383 or away == 1589 or away == 386 or away == 104 or away == 205 or away == 387 or away == 388 or away == 389 or away == 4192 or away == 1327 or away == 391 or away == 4193 or away == 4194 or away == 394 or away == 395 or away == 1909 or away == 399 or away == 400) then
	        CornerFlag = "EFL\\Championship"
	    elseif (home == 199 or home == 2293 or home == 2297 or home == 2298 or home == 2300 or home == 2301 or home == 2344 or home == 2345 or home == 2346 or home == 2347 or home == 2348 or home == 2349 or home == 2350 or home == 2351 or home == 2352 or home == 2353 or home == 2354 or home == 2355 or home == 2356 or home == 2357) and (away == 199 or away == 2293 or away == 2297 or away == 2298 or away == 2300 or away == 2301 or away == 2344 or away == 2345 or away == 2346 or away == 2347 or away == 2348 or away == 2349 or away == 2350 or away == 2351 or away == 2352 or away == 2353 or away == 2354 or away == 2355 or away == 2356 or away == 2357) then
	        CornerFlag = "Bundesliga"
	    elseif (home == 234 or home == 186 or home == 320 or home == 188 or home == 235 or home == 124 or home == 323 or home == 119 or home == 120 or home == 122 or home == 121 or home == 327 or home == 123 or home == 125 or home == 240 or home == 1919 or home == 4923 or home == 4234 or home == 333 or home == 190) and (away == 234 or away == 186 or away == 320 or away == 188 or away == 235 or away == 124 or away == 323 or away == 119 or away == 120 or away == 122 or away == 121 or away == 327 or away == 123 or away == 125 or away == 240 or away == 1919 or away == 4923 or away == 4234 or away == 333 or away == 190) then
	        CornerFlag = "Serie A"
            elseif (home == 109) and (away == 258 or away == 172 or away == 108 or away == 195 or away == 4145 or away == 4146 or away == 259 or away == 362 or away == 2187 or away == 2188 or away == 4272 or away == 366 or away == 370 or away == 194 or away == 109 or away == 196 or away == 266 or away == 265 or away == 110 or away == 267) then
                CornerFlag = "Teams\\Real Madrid\\Liga"
	    elseif (home == 258 or home == 172 or home == 108 or home == 195 or home == 4145 or home == 4146 or home == 259 or home == 362 or home == 2187 or home == 2188 or home == 4272 or home == 366 or home == 370 or home == 194 or home == 196 or home == 266 or home == 265 or home == 110 or home == 267) and (away == 258 or away == 172 or away == 108 or away == 195 or away == 4145 or away == 4146 or away == 259 or away == 362 or away == 2187 or away == 2188 or away == 4272 or away == 366 or away == 370 or away == 194 or away == 109 or away == 196 or away == 266 or away == 265 or away == 110 or away == 267) then
	        CornerFlag = "LaLiga"
	    elseif (home == 199 or home == 2293 or home == 2297 or home == 2298 or home == 2300 or home == 2301 or home == 2344 or home == 2345 or home == 2346 or home == 2347 or home == 2348 or home == 2349 or home == 2350 or home == 2351 or home == 2352 or home == 2353 or home == 2354 or home == 2355 or home == 2356 or home == 2357) and (away == 199 or away == 2293 or away == 2297 or away == 2298 or away == 2300 or away == 2301 or away == 2344 or away == 2345 or away == 2346 or away == 2347 or away == 2348 or away == 2349 or away == 2350 or away == 2351 or away == 2352 or away == 2353 or away == 2354 or away == 2355 or away == 2356 or away == 2357) then
	        CornerFlag = "Bundesliga"
	    elseif (home == 243 or home == 116 or home == 242 or home == 339 or home == 342 or home == 344 or home == 117 or home == 345 or home == 244 or home == 245 or home == 349 or home == 246 or home == 256 or home == 118 or home == 251 or home == 252 or home == 355 or home == 255) and (away == 243 or away == 116 or away == 242 or away == 339 or away == 342 or away == 344 or away == 117 or away == 345 or away == 244 or away == 245 or away == 349 or away == 246 or away == 256 or away == 118 or away == 251 or away == 252 or away == 355 or away == 255) then
	        CornerFlag = "Eredivisie"
	    elseif (home == 2623 or home == 5202 or home == 5360 or home == 1989 or home == 5353 or home == 273 or home == 1991 or home == 197 or home == 130 or home == 5203 or home == 1995 or home == 2625 or home == 1996 or home == 5204 or home == 5354 or home == 1809 or home == 1945 or home == 5206) and (away == 2623 or away == 5202 or away == 5360 or away == 1989 or away == 5353 or away == 273 or away == 1991 or away == 197 or away == 130 or away == 5203 or away == 1995 or away == 2625 or away == 1996 or away == 5204 or away == 5354 or away == 1809 or away == 1945 or away == 5206) then
	        CornerFlag = "Super Lig"
	    elseif (home == 174 or home == 5191 or home == 2009 or home == 269 or home == 1195 or home == 1196 or home == 5190 or home == 2013 or home == 5192 or home == 1199 or home == 5193 or home == 5194 or home == 2010 or home == 1197 or home == 5195 or home == 2019) and (away == 174 or away == 5191 or away == 2009 or away == 269 or away == 1195 or away == 1196 or away == 5190 or away == 2013 or away == 5192 or away == 1199 or away == 5193 or away == 5194 or away == 2010 or away == 1197 or away == 5195 or away == 2019) then
	        CornerFlag = "Jupiler Pro League"
	    elseif (home == 2717 or home == 1236 or home == 2719 or home == 1927 or home == 2536 or home == 139 or home == 1923 or home == 2722 or home == 1238 or home == 1239 or home == 1924 or home == 1922 or home == 1240 or home == 1929 or home == 1241 or home == 2729 or home == 1237 or home == 138 or home == 1242 or home == 1243 or home == 1925 or home == 2702 or home == 5046 or home == 1926 or home == 2538 or home == 1244) and (away == 2717 or away == 1236 or away == 2719 or away == 1927 or away == 2536 or away == 139 or away == 1923 or away == 2722 or away == 1238 or away == 1239 or away == 1924 or away == 1922 or away == 1240 or away == 1929 or away == 1241 or away == 2729 or away == 1237 or away == 138 or away == 1242 or away == 1243 or away == 1925 or away == 2702 or away == 5046 or away == 1926 or away == 2538 or away == 1244) then
	        CornerFlag = "Superliga Argentina"
		elseif (home == 2450 or home == 1245 or home == 1930 or home == 2453 or home == 1246 or home == 2454 or home == 4108 or home == 1247 or home == 274 or home == 1248 or home == 1249 or home == 1250 or home == 1252 or home == 137 or home == 2464 or home == 1254 or home == 1255 or home == 1936 or home == 136 or home == 1937) and (away == 2450 or away == 1245 or away == 1930 or away == 2453 or away == 1246 or away == 2454 or away == 4108 or away == 1247 or away == 274 or away == 1248 or away == 1249 or away == 1250 or away == 1252 or away == 137 or away == 2464 or away == 1254 or away == 1255 or away == 1936 or away == 136 or away == 1937) then
			CornerFlag = "Brasileiro"
		else
			CornerFlag = "Default"
		end
	else
		CornerFlag = "Default"
    end

    if tid then
       return string.format("%s:%s", CornerFlag, filename)
    end
end

local function get_filepath(ctx, filename, key)
    if key then
        return string.format("%s\\%s\\%s", fileroot, CornerFlag, filename)
    end
end

local function trophy_rewrite(ctx, tournament_id)
	   log("-- " .. CornerFlag)
end

local function init(ctx)
    if fileroot:sub(1,1)=='.' then
        fileroot = ctx.sider_dir .. fileroot
    end
	ctx.register("set_teams", set_random)
    ctx.register("livecpk_make_key", make_key)
    ctx.register("livecpk_get_filepath", get_filepath)
    ctx.register("trophy_rewrite", trophy_rewrite)
end

return { init = init }